
for i in */*.bmp
do dir=`dirname $i | sed 's/_Classic/_1024x768/'`
   file=`basename $i .bmp`
   if [ ! -f $dir/$file@2x.png ]; then echo $i; fi
done
