for dir in Sprites_*
do cd $dir
	for i in Maelstrom_icl#3*
	do new=`echo $i | sed 's/icl/ics/'`
	   hg mv $i $new
	   cp $new $i
	   svn rm $i
	   svn add $new
	done
   cd ..
done
